#ifndef OPERATINGSYSTEM_H
#define OPERATINGSYSTEM_H

#include "ComputerSystem.h"
#include <stdio.h>


#define SUCCESS 1
#define PROGRAMDOESNOTEXIST -1
#define PROGRAMNOTVALID -2

#define NOFREEENTRY -3
#define TOOBIGPROCESS -4

#define NOPROCESS -1

// Adiciones de la V2
#define SLEEPINGQUEUE

// Number of queues of ready to run processes, initially one queue...
#define NUMBEROFQUEUES 3
enum TypeOfReadyToRunProcessQueues { HIGHPRIOUSERPROCQUEUE, LOWPRIOUSERPROCQUEUE, DEAMONSQUEUE};

// Contains the possible type of programs
enum ProgramTypes { USERPROGRAM=100, DAEMONPROGRAM }; 

// Enumerated type containing all the possible process states
enum ProcessStates { NEW, READY, EXECUTING, BLOCKED, EXIT};

// Enumerated type containing the list of system calls and their numeric identifiers
enum SystemCallIdentifiers { 
	SYSCALL_END=3,
	SYSCALL_YIELD=4, 
	SYSCALL_PRINTEXECINFO=5,
	SYSCALL_SLEEP=7,
	SYSCALL_LOAD= 11
};

// A PCB contains all of the information about a process that is needed by the OS
typedef struct {
	int busy;
	int initialPhysicalAddress;
	int processSize;
	int copyOfSPRegister;
	int state;
	int priority;
	int copyOfPCRegister;
	unsigned int copyOfPSWRegister;
	int copyOfAccumulator; 
	int copyOfRegisterA; 
	int copyOfRegisterB;
	int programListIndex;
	int queueID;
	// V2 - Ejercicio 5 
	int whenToWakeUp;
} PCB;

// These "extern" declaration enables other source code files to gain access
// to the variable listed


// Functions prototypes
void OperatingSystem_Initialize(int);
void OperatingSystem_InterruptLogic(int);
int OperatingSystem_ShortTermScheduler();
void OperatingSystem_Dispatch(int);
void OperatingSystem_HandleClockInterrupt();
#endif
